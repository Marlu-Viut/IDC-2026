"""Ejecuta todas las celdas en una sesión IPython nueva y conserva sus salidas.

Alternativa reproducible al kernel Jupyter cuando no se permite abrir sockets.
Los contadores provienen de IPython, no de una numeración añadida a posteriori.
"""
from pathlib import Path
from datetime import datetime, timezone
import os
import nbformat
from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output


def main():
    base = Path(__file__).resolve().parent
    os.chdir(base)
    ruta = base / 'Farmacias_Ensenada_EDA_Geoespacial.ipynb'
    notebook = nbformat.read(ruta, as_version=4)
    shell = InteractiveShell.instance()
    for indice, celda in enumerate(notebook.cells):
        if celda.cell_type != 'code':
            continue
        print(f'Ejecutando celda {indice}: {celda.source.splitlines()[0][:85]}', flush=True)
        inicio = datetime.now(timezone.utc).isoformat()
        with capture_output() as capturado:
            resultado = shell.run_cell(celda.source, store_history=True)
        celda.execution_count = resultado.execution_count
        celda.outputs = []
        if capturado.stdout:
            celda.outputs.append(nbformat.v4.new_output('stream',name='stdout',text=capturado.stdout))
        if capturado.stderr:
            celda.outputs.append(nbformat.v4.new_output('stream',name='stderr',text=capturado.stderr))
        for salida in capturado.outputs:
            celda.outputs.append(nbformat.v4.new_output('display_data',data=salida.data,
                                                       metadata=salida.metadata))
        celda.metadata['execution'] = {'inicio_utc':inicio,
            'fin_utc':datetime.now(timezone.utc).isoformat(),'motor':'IPython secuencial'}
        error = resultado.error_before_exec or resultado.error_in_exec
        if error:
            nbformat.write(notebook,base/'ejecucion_parcial.ipynb')
            raise RuntimeError(f'Falló la celda {indice}: {error}') from error
    nbformat.validate(notebook)
    nbformat.write(notebook,ruta)
    print('EJECUCIÓN COMPLETA. Celdas de código:',shell.execution_count-1,flush=True)


if __name__ == '__main__':
    main()
