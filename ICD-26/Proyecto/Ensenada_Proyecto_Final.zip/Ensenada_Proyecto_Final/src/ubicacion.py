"""Métodos de localización: cobertura adicional de población, sin duplicarla."""
import time
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.sparse import csr_matrix, csc_matrix, eye, hstack, vstack
from scipy.optimize import milp, Bounds, LinearConstraint
from sklearn.cluster import KMeans
from sklearn.model_selection import GroupKFold


def matriz_cobertura(xy_candidatos, xy_demanda, radio):
    """Fila = ubicación candidata, columna = manzana inicialmente desatendida."""
    vecinos = cKDTree(xy_demanda).query_ball_point(xy_candidatos, radio + 1e-6)
    filas = np.repeat(np.arange(len(vecinos)), [len(v) for v in vecinos])
    columnas = np.concatenate(vecinos).astype(int)
    return csr_matrix((np.ones(len(filas), dtype=np.int32), (filas, columnas)),
                      shape=(len(xy_candidatos), len(xy_demanda)))


def cubierta_por(a, seleccion):
    return np.asarray(a[seleccion].sum(axis=0)).ravel() > 0


def seleccion_voraz(a, pesos, k, minimo=0):
    """Añade el mayor beneficio marginal. Los empates siguen el orden de clave."""
    pendientes = np.ones(a.shape[1], dtype=bool)
    seleccion, ganancias = [], []
    for _ in range(k):
        beneficio = np.asarray(a @ (pesos * pendientes)).ravel().astype(float)
        beneficio[seleccion] = -1
        mejor = int(beneficio.argmax())
        if beneficio[mejor] <= 0 or beneficio[mejor] < minimo:
            break
        seleccion.append(mejor)
        ganancias.append(float(beneficio[mejor]))
        pendientes[a[mejor].indices] = False
    return seleccion, ganancias


def seleccion_kmeans(xy_demanda, xy_candidatos, pesos, k, semilla):
    """K-means ponderado, seguido de ajuste a candidatos distintos permitidos."""
    usar = pesos > 0
    modelo = KMeans(n_clusters=k, n_init=10, random_state=semilla)
    modelo.fit(xy_demanda[usar], sample_weight=pesos[usar])
    seleccion = []
    for centro in modelo.cluster_centers_:
        orden = np.argsort(np.linalg.norm(xy_candidatos - centro, axis=1), kind='stable')
        seleccion.append(next(int(i) for i in orden if int(i) not in seleccion))
    return seleccion


def resolver_mclp(a, pesos, k, segundos=30):
    """MCLP discreto. La brecha informa si el solucionador certifica optimalidad."""
    m, n = a.shape
    restricciones = vstack([
        hstack([-a.T, eye(n)]),
        csr_matrix(np.r_[np.ones(m), np.zeros(n)].reshape(1, -1))
    ], format='csc')
    inicio = time.perf_counter()
    resultado = milp(
        c=np.r_[np.zeros(m), -pesos / 1000],
        integrality=np.r_[np.ones(m), np.zeros(n)],
        bounds=Bounds(0, 1),
        constraints=LinearConstraint(restricciones, -np.inf, np.r_[np.zeros(n), k]),
        options={'time_limit': segundos, 'mip_rel_gap': 0.0, 'presolve': True})
    seleccion = ([] if resultado.x is None else
                 np.flatnonzero(resultado.x[:m] > .5).tolist())
    ficha = {'estado': int(resultado.status), 'mensaje': resultado.message,
             'segundos': time.perf_counter() - inicio,
             'brecha_relativa': float(getattr(resultado, 'mip_gap', np.nan)),
             'cota_superior_personas': -1000 * float(
                 getattr(resultado, 'mip_dual_bound', np.nan))}
    return seleccion, ficha


def comparar_completo(a, xy, candidatos_xy, pesos, k=5, repeticiones=30, semilla=42):
    """Mismo universo, radio, candidatos y presupuesto para todos los métodos."""
    filas, soluciones = [], {}
    for r in range(repeticiones):
        s = semilla + r
        rng = np.random.default_rng(s)
        for nombre, elegidos in [
            ('Aleatorio', rng.choice(a.shape[0], k, replace=False).tolist()),
            ('K-means ponderado', seleccion_kmeans(xy, candidatos_xy, pesos, k, s))]:
            beneficio = int(pesos[cubierta_por(a, elegidos)].sum())
            filas.append(dict(metodo=nombre, semilla=s, k=k,
                              poblacion_adicional=beneficio))
            soluciones[(nombre, s)] = elegidos
    elegidos, _ = seleccion_voraz(a, pesos, k)
    soluciones[('Voraz', semilla)] = elegidos
    filas.append(dict(metodo='Voraz', semilla=semilla, k=len(elegidos),
                      poblacion_adicional=int(pesos[cubierta_por(a, elegidos)].sum())))
    elegidos, ficha = resolver_mclp(a, pesos, k)
    soluciones[('MCLP', semilla)] = elegidos
    if elegidos:
        filas.append(dict(metodo='MCLP', semilla=semilla, k=len(elegidos),
                          poblacion_adicional=int(pesos[cubierta_por(a, elegidos)].sum())))
    return pd.DataFrame(filas), soluciones, ficha


def evaluar_bloques(a, xy, candidatos_xy, pesos, grupos, k=5, semilla=42):
    """Prueba de transferencia espacial: los pesos del bloque evaluado se ocultan.

    La geometría de todos los candidatos es pública y se fija antes de partir.
    Esto no estima futuras aperturas ni una muestra aleatoria de habitantes.
    """
    resultados, particiones = [], []
    for fold, (entrena, prueba) in enumerate(GroupKFold(5).split(xy, groups=grupos), 1):
        assert not set(grupos[entrena]) & set(grupos[prueba])
        pesos_entrena = np.zeros_like(pesos)
        pesos_entrena[entrena] = pesos[entrena]
        rng = np.random.default_rng(semilla + fold)
        soluciones = {
            'Aleatorio': rng.choice(a.shape[0], k, replace=False).tolist(),
            'K-means ponderado': seleccion_kmeans(
                xy, candidatos_xy, pesos_entrena, k, semilla),
            'Voraz': seleccion_voraz(a, pesos_entrena, k)[0]}
        for nombre, seleccion in soluciones.items():
            mascara = cubierta_por(a, seleccion)[prueba]
            resultados.append(dict(fold=fold, metodo=nombre,
                poblacion_prueba=int(pesos[prueba].sum()),
                poblacion_adicional=int(pesos[prueba][mascara].sum()),
                porcentaje_brecha_cerrada=100 * pesos[prueba][mascara].sum()/pesos[prueba].sum()))
        particiones.extend(dict(indice=int(i), fold_prueba=fold, bloque=str(grupos[i]))
                           for i in prueba)
    return pd.DataFrame(resultados), pd.DataFrame(particiones)
