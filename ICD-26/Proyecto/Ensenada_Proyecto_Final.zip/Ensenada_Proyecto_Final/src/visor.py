"""Visor Leaflet autocontenido, con cartografía de INEGI siempre visible."""
import json
import numpy as np


def geojson(g, columnas=(), tolerancia=2):
    t = g[list(columnas) + ['geometry']].to_crs('EPSG:32611').copy()
    if tolerancia:
        t.geometry = t.geometry.simplify(tolerancia, preserve_topology=True)
    return json.loads(t.to_crs('EPSG:4326').to_json(drop_id=True, na='null'))


def crear_visor(destino, assets, tierra, vias, base, manzanas, servicios,
                propuestas, rejilla, dist_prefix, radio, k_principal):
    manzanas = manzanas.copy().reset_index(drop=True)
    manzanas['indice'] = np.arange(len(manzanas))
    pop = manzanas.POBTOT.to_numpy()
    metricas = [dict(k=k, cubierta=int(pop[d <= radio].sum()),
                    adicional=int(pop[d <= radio].sum()-pop[dist_prefix[0] <= radio].sum()),
                    porcentaje=round(100*pop[d <= radio].sum()/pop.sum(), 2))
                for k, d in enumerate(dist_prefix)]
    circulos = servicios['Farmacias'].copy()
    circulos.geometry = circulos.geometry.buffer(radio, quad_segs=48)
    nuevas = propuestas.copy()
    nuevas.geometry = nuevas.geometry.buffer(radio, quad_segs=48)
    # Etiquetas del fondo: se conservan nombres de vialidades realmente publicados.
    calles = vias.loc[vias.NOMVIAL.notna() & ~vias.NOMVIAL.str.lower().isin(
        ['ninguno', 'sin nombre', 'ninguna'])].copy()
    calles['longitud_m'] = calles.length
    nombres = calles.groupby('NOMVIAL').longitud_m.sum().nlargest(10).index
    etiquetas = []
    for nombre in nombres:
        segmento = calles.loc[calles.NOMVIAL.eq(nombre)].sort_values('longitud_m').iloc[-1]
        p = segmento.geometry.interpolate(.5, normalized=True)
        import geopandas as gpd
        p = gpd.GeoSeries([p], crs=vias.crs).to_crs('EPSG:4326').iloc[0]
        etiquetas.append(dict(texto=nombre,lat=p.y,lon=p.x))
    contenido = dict(
        tierra=geojson(tierra,tolerancia=5),vias=geojson(vias,tolerancia=2),
        base=geojson(base,tolerancia=3),
        manzanas=geojson(manzanas,['indice','clave_manzana','POBTOT','distancia_m']),
        servicios={n:geojson(g,['id','nom_estab','nombre_act','nomb_asent'],0) for n,g in servicios.items()},
        propuestas=geojson(propuestas,['orden','id_propuesta','clave_manzana','poblacion_marginal','asentamiento_referencia_denue'],0),
        circulos=geojson(circulos,['id'],1),circulos_nuevos=geojson(nuevas,['orden'],1),
        rejilla=geojson(rejilla,['poblacion','manzanas']),
        distancias=[np.round(d,1).tolist() for d in dist_prefix],
        metricas=metricas,poblacion=int(pop.sum()),radio=radio,k=k_principal,
        etiquetas=etiquetas)
    plantilla = (assets/'visor_template.html').read_text()
    css = (assets/'leaflet.css').read_text()
    js = (assets/'leaflet.js').read_text()
    texto = (plantilla.replace('/* LEAFLET_CSS */',css)
             .replace('/* LEAFLET_JS */',js)
             .replace('/* DATOS_JSON */',json.dumps(contenido,ensure_ascii=False,
                          separators=(',',':')).replace('</','<\\/')))
    destino.write_text(texto)
