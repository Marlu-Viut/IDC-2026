# Accesibilidad a farmacias en Ensenada

**Autora:** María Guadalupe Villanueva Utrilla  
**Curso:** Introducción a la Ciencia de Datos, CICESE  
**Repositorio:** [IDC-2026 / Proyecto](https://github.com/Marlu-Viut/IDC-2026/tree/main/ICD-26/Proyecto)

## Objetivo y alcance

Identificar las manzanas pobladas más alejadas de una farmacia y proponer cinco ubicaciones que aumenten la población cubierta con un radio de **500 metros**. También se estudia **cómo se relaciona la distancia a la farmacia más cercana con la densidad de población y la ubicación de las manzanas** mediante regresión.

El área de estudio es la localidad de Ensenada, clave **020010001**. La unidad de análisis es la manzana censal; los resultados no representan todo el municipio ni una clasificación por colonias.

El análisis cuantitativo se limita a farmacias. Hospitales, supermercados y centros educativos aparecen únicamente como categorías de puntos en el mapa. No se incluyen bancos o cajeros ni se realizan estudios sociodemográficos con variables incompletas.

## Archivos de la entrega

| Archivo | Contenido |
|---|---|
| `Villanueva_Farmacias_Ensenada.ipynb` | Notebook con datos, EDA, preprocesamiento, localización, regresión, evaluación y conclusiones. Se entrega con sus salidas visibles. |
| `Ensenada_Proyecto_Final.zip` | Código y recursos necesarios para ejecutar el notebook: carpeta principal `Ensenada_Proyecto_Final/`, con `src/`, `assets/` y `requirements.txt`. |
| `Mapa_de_Cobertura.html` | Visor interactivo exportado para consultar los resultados. |
| PDF de la presentación | Exposición del proyecto, con portada y ocho diapositivas de contenido. |
| PDF del reporte | Artículo con métodos, resultados, interpretación, limitaciones y referencias. |
| `README.md` | Descripción del proyecto e instrucciones de reproducción. |

El notebook se entrega **fuera del ZIP**. No es necesario que el ZIP contenga las bases originales: el notebook las descarga en la primera ejecución. Deben conservarse los nombres y la organización interna de `src/` y `assets/`.

Dentro de `src/` se utilizan:

- `ubicacion.py`: cobertura, selección aleatoria, K-means, algoritmo voraz y optimización de cobertura máxima.
- `regresion.py`: preparación de variables, partición espacial, modelos, validación y diagnóstico.
- `visor.py`: construcción del mapa HTML.

En `assets/` se requieren `leaflet.js`, `leaflet.css` y `visor_template.html`; se conserva la licencia de Leaflet.

## Ejecutar en Google Colab

La celda inicial de reproducibilidad del notebook está preparada para **Google Colab** y espera esta ruta después de descomprimir:

```text
/content/Ensenada_Proyecto_Final/
```

1. Descarga `Villanueva_Farmacias_Ensenada.ipynb` y `Ensenada_Proyecto_Final.zip` desde la entrega o el repositorio.
2. Abre el notebook en [Google Colab](https://colab.research.google.com/) mediante **Archivo > Subir notebook**.
3. Utiliza un entorno con CPU. No se necesita GPU.
4. Ejecuta la primera celda, titulada `Reproducibilidad`. Cuando aparezca el selector de archivos, carga **`Ensenada_Proyecto_Final.zip`**. La celda lo descomprime y establece la carpeta de trabajo.
5. Ejecuta las demás celdas en orden. El notebook prepara las dependencias faltantes, descarga las fuentes y genera las tablas, figuras, modelos y el HTML. La descarga inicial requiere internet.
6. Para guardar una ejecución completa con contadores consecutivos, reinicia la sesión de Python y ejecuta todas las celdas desde el principio. Mientras los archivos permanezcan en `/content`, la celda inicial no volverá a solicitar el ZIP.
7. Descarga el notebook ejecutado desde **Archivo > Descargar > Descargar .ipynb** y comprueba que conserva tablas, figuras y conclusiones.

Si Colab elimina el entorno, vuelve a cargar el ZIP. Subir solamente el notebook a una sesión nueva no proporciona los módulos de `src/` ni los recursos de `assets/`.

**Contenido del ZIP:** debe incluir la carpeta superior `Ensenada_Proyecto_Final/`. Si contiene directamente `src/` y `assets/` sin esa carpeta, la celda inicial no encontrará la ruta esperada.

### Recuperar el mapa generado

La ejecución genera el visor en:

```text
/content/Ensenada_Proyecto_Final/resultados/Mapa_Ensenada_Cobertura_Actual_y_Ficticia.html
```

Puede descargarse desde el panel de archivos de Colab. Si el notebook incluye una celda con `files.download(...)`, esa celda descarga el mismo archivo. Para presentarlo se puede guardar una copia con el nombre **`Mapa_de_Cobertura.html`**; cambiar el nombre de la copia no cambia la ruta que utiliza el código.

La declaración de uso de IA debe permanecer como última celda del notebook. Cualquier celda adicional de descarga debe colocarse antes de ella.

## Ejecutar en una computadora local

Se recomienda **Python 3.12** y un entorno virtual nuevo. Descomprime el ZIP y coloca una copia del notebook dentro de la carpeta `Ensenada_Proyecto_Final/`, junto a `src/`, `assets/` y `requirements.txt`.

La primera celda de reproducibilidad importa `google.colab` y utiliza `/content`; **omítela o retírala en la copia destinada a ejecución local**. Si existe una celda final de descarga que importa `google.colab`, omítela también. El análisis debe ejecutarse con la carpeta del proyecto como directorio de trabajo.

Desde esa carpeta, en Linux o macOS:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install notebook
python -m notebook
```

En Windows, activa el entorno con `.venv\Scripts\activate` en lugar de `source .venv/bin/activate` y continúa con los comandos de instalación y apertura.

Abre `Villanueva_Farmacias_Ensenada.ipynb` y reinicia el kernel antes de ejecutar las celdas del análisis en orden. `requirements.txt` registra las versiones del análisis; la ejecución guarda información del entorno en `resultados/versiones.json`.

El archivo auxiliar `ejecutar_notebook.py` incluido en el ZIP corresponde al nombre original del notebook. Estas instrucciones utilizan la ejecución interactiva y no dependen de ese script. Si se modificaron archivos del paquete, el manifiesto SHA-256 original debe regenerarse antes de utilizarlo para verificar la nueva entrega.

## Datos y descarga automática

| Fuente | Edición | Uso |
|---|---|---|
| Censo de Población y Vivienda, INEGI | 2020, AGEB y manzana urbana de Baja California | Población total por manzana. |
| Marco Geoestadístico, INEGI | Censo 2020, Baja California | Polígonos, claves geográficas y cartografía de contexto. |
| DENUE, INEGI | Mayo de 2025, Baja California | Localización y categoría de establecimientos. |

El notebook descarga estas ediciones y crea `datos/entradas/`. Las bases originales no se incluyen en el ZIP. Si una descarga falla, coloca el ZIP original de la misma edición en esa carpeta con el nombre indicado:

| Archivo local | Descarga |
|---|---|
| `censo_2020_bc.zip` | [Censo 2020 por AGEB y manzana](https://www.inegi.org.mx/contenidos/programas/ccpv/2020/datosabiertos/ageb_manzana/ageb_mza_urbana_02_cpv2020_csv.zip) |
| `marco_geoestadistico_2020_bc.zip` | [Marco Geoestadístico de Baja California](https://www.inegi.org.mx/contenidos/productos/prod_serv/contenidos/espanol/bvinegi/productos/geografia/marcogeo/889463807469/02_bajacalifornia.zip) |
| `denue_2025_05_bc.zip` | [DENUE de Baja California, mayo de 2025](https://www.inegi.org.mx/contenidos/masiva/denue/2025_05/denue_02_0525_csv.zip) |

La unión entre población y polígonos utiliza la **clave completa de manzana de 16 caracteres**, conservando ceros iniciales. Áreas, distancias y círculos se calculan en **EPSG:32611, WGS 84 / UTM zona 11 norte**, con unidades en metros. Las claves sin polígono utilizable se documentan; no se les inventa geometría ni población.

Las fuentes se atribuyen a INEGI. Las transformaciones y propuestas son elaboración del proyecto y no implican aval del Instituto. Consulta las [condiciones de uso de INEGI](https://www.inegi.org.mx/inegi/terminos.html).

## Metodología

1. **EDA y preprocesamiento:** revisar fuentes, claves, duplicados, población, geometrías, coordenadas y distribución espacial; unir población y polígonos y documentar exclusiones.
2. **Accesibilidad actual:** calcular la distancia recta del punto representativo de cada manzana a la farmacia más cercana. Se consideran destinos de Baja California para reducir el efecto de recortar las farmacias en el borde de la localidad.
3. **Localización:** comparar cinco ubicaciones aleatorias, K-means ponderado por población y selección voraz. El voraz elige en cada paso el sitio que incorpora más población todavía no cubierta. Se contrasta con un modelo de cobertura máxima, MCLP, resuelto con HiGHS. Los círculos tienen igual radio; los buffers de farmacias existentes no son clusters aprendidos.
4. **Regresión:** comparar una mediana de referencia y especificaciones con densidad, coordenadas y términos geográficos cuadráticos. La respuesta es `log(1 + distancia)`; las métricas se calculan en metros al regresar a la escala original.
5. **Evaluación espacial:** separar entrenamiento y prueba por bloques de 1 km, con semilla 42. Seleccionar por MAE de validación cruzada en cinco particiones del entrenamiento y evaluar después en la prueba reservada. El escalado se aprende dentro de cada ajuste.
6. **Interpretación:** analizar errores, sensibilidad al radio, estabilidad de la asociación con densidad y autocorrelación espacial de los residuos.

Para las comparaciones aleatorias y K-means se utilizan 30 semillas, de 42 a 71, con diez inicializaciones de K-means. La cobertura cuenta una sola vez la población asociada a una manzana, aunque varios círculos la alcancen.

## Resultados de referencia

Cifras de la ejecución del proyecto, sujetas a las ediciones y parámetros anteriores:

| Indicador | Resultado |
|---|---:|
| Manzanas habitadas con geometría utilizable | 5521 |
| Población incluida | 330562 |
| Población excluida por falta de polígono utilizable | 90 |
| Farmacias dentro de la localidad | 165 |
| Población inicialmente cubierta a 500 m | 189441 (57.31 %) |
| Población adicional cubierta con cinco propuestas voraces | 31188 |
| Población cubierta después de cinco propuestas | 220629 (66.74 %) |
| Población que permanece fuera del radio | 109933 |
| MAE de prueba de la regresión seleccionada | 298.6 m |
| MAE de prueba de la mediana de referencia | 414.1 m |
| RMSE de prueba de la regresión seleccionada | 497.0 m |
| R² de prueba de la regresión seleccionada | 0.357 |

MCLP alcanza el mismo beneficio que el método voraz y lo certifica con brecha cero **para el conjunto de candidatos y parámetros evaluados**. Esto no garantiza viabilidad de los predios ni optimalidad general del algoritmo voraz.

La regresión seleccionada utiliza ubicación con términos cuadráticos. La densidad por sí sola no mejora la referencia; su asociación negativa se debilita al flexibilizar la tendencia geográfica. Persiste estructura espacial en los residuos y variación importante entre particiones. Se conserva un error extremo de aproximadamente 3801 m observados frente a 15154 m estimados. La regresión permite estudiar asociaciones y tiene capacidad predictiva limitada; no demuestra causalidad ni decide las ubicaciones propuestas.

Las tablas, figuras, auditorías y métricas se regeneran bajo `resultados/`; el modelo seleccionado se guarda en `modelos/`. No es necesario crear previamente esas carpetas. Los PDFs de presentación y reporte se entregan por separado y no se recompilan al ejecutar el notebook.

## Consultar el HTML

Abre **`Mapa_de_Cobertura.html`** en un navegador. El visor generado incorpora Leaflet, datos y un fondo vectorial de costa, calles y manzanas: no necesita teselas de OpenStreetMap ni conexión para mostrar el mapa. El fondo permanece visible al cambiar las capas.

Permite consultar la situación actual, cinco propuestas, población, distancias, manzanas fuera del radio, círculos de 500 m, concentraciones inicialmente desatendidas y escenarios de cero a diez propuestas. Hospitales, supermercados y centros educativos pueden activarse por categoría como contexto visual.

Ocultar una capa cambia su visualización; el número de propuestas seleccionado sigue definiendo el escenario de los indicadores. Los nombres de asentamientos cercanos a las propuestas son referencias de DENUE y no equivalen a polígonos de colonias validados.

## Limitaciones

- Las distancias son rectas; no representan tiempos de caminata, barreras ni rutas seguras. Los ejes viales dibujados no constituyen una red peatonal validada para calcular trayectos.
- El punto representativo de una manzana aproxima la ubicación de sus habitantes. La cobertura es población asociada a esos puntos, no una medición de cada domicilio.
- Se combinan población de 2020 y establecimientos de 2025. No se conocen todos los cambios posteriores, horarios, capacidad, precios o disponibilidad de medicamentos.
- El radio de 500 m y el presupuesto de cinco propuestas son escenarios de planificación; no son estándares clínicos ni estimaciones de rentabilidad.
- Los sitios candidatos requieren validación de predios y factibilidad. El objetivo es priorizar población desatendida, no cubrir toda la superficie con nuevas farmacias.
- Los estudios sobre mayores de 60 años, necesidades familiares, rentas, reseñas u horarios de 24 horas requieren datos adicionales completos, vinculados y verificados. Aquí se mencionan como extensiones, sin atribuirles resultados.



## Uso de IA generativa

Se utilizó ChatGPT (OpenAI) como apoyo para programar, revisar el análisis y el visor, y preparar borradores de documentación. 
